<?php
// Process form data and save to database or file
$response = array();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $name = isset($_POST['name']) ? $_POST['name'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';

    // Perform validation and save to the database or file
    // For simplicity, let's just create a response array
    $response['status'] = 'success';
    $response['message'] = 'Form data saved successfully!';
} else {
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method.';
}

// Send JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>

