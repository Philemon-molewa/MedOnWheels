<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<header class="masthead">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-10 align-self-end mb-4" style="background: #0000002e;">
                    	 <h1 class="text-uppercase text-white font-weight-bold">Frequently Asked Questions</h1>
                        <hr class="divider my-4" />
                    </div>
                    
                </div>
            </div>
        </header>
	
    
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f8f8;
            color: #333;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        header {
            background-color: #4CAF50; /* Green color */
            color: white;
            text-align: center;
            padding: 1em;
        }

        section {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        h2 {
            color: #4CAF50; /* Green color */
            cursor: pointer;
        }

        p {
            display: none;
        }
    </style>
</head>
<body>



<!-- FAQ Section -->
<section>
    <h2 onclick="toggleAnswer('placeOrder')">*How to place an order?</h2>
    <p id="placeOrder">To place an order, follow these steps: <br>1.Sign in or create an account with your email and phone number.<br>
			2.Enter your delivery address and browse the medicines available near you, or search for the medicine you want.<br>
            3.Select the items you want to order and add them to your cart.<br>
            4.Review your order and choose your payment method. You can also apply a promo code or a gift card if you have one.<br>
            5.Place your order and track its progress on the website.<br>
            6.Enjoy your medicine and rate your experience.<br>
        
    </p>

   

    <h2 onclick="toggleAnswer('deliveryTime')">*How long will delivery take?</h2>
    <p id="deliveryTime">The average MedOnWheels delivery time is approximately between 2-3 hours. However, this may vary depending on factors such as the pharmacy's preparation time, the distance between the pharmacy and the delivery address, traffic conditions, and the availability of delivery persons. You can track your order's progress on the website to get a more accurate estimate of the delivery time.</p>

    <h2 onclick="toggleAnswer('deliveryCost')">*How much does the delivery cost?</h2>
    <p id="deliveryCost">The delivery cost for MedOnWheels depends on various factors, such as the pharmacy, the distance, the demand, and the time of the order. Please check the delivery cost during the checkout process for accurate information.</p>

    <h2 onclick="toggleAnswer('confidentialInfo')">*Is my personal and medical information with MedOnWheels kept confidential?</h2>
    <p id="confidentialInfo">MedOnWheels recognizes the need to keep patient information confidential. MedOnWheels is Health Insurance Portability and Accountability Act (HIPAA) compliant and uses industry best standards for data privacy, backup, and recovery.</p>

	<h2 onclick="toggleAnswer('paymentMethods')">*What payment methods are accepted?</h2>
    <p id="paymentMethods" class="answer">We accept EFT, cash, card on delivery, and medical aid as payment methods.</p>

    <h2 onclick="toggleAnswer('needAccount')">*Do I need an account on MedOnWheels to place an order?</h2>
    <p id="needAccount" class="answer">Yes, you need to create an account on MedOnWheels before placing an order.</p>

    <h2 onclick="toggleAnswer('returnPolicy')">*What is the return policy?</h2>
    <p id="returnPolicy" class="answer">No, once medication has been ordered and paid for, there are no returns or refunds.</p>

</section>


<script>
    function toggleAnswer(id) {
        var answer = document.getElementById(id);
        if (answer.style.display === "none" || answer.style.display === "") {
            answer.style.display = "block";
        } else {
            answer.style.display = "none";
        }
    }
</script>

</body>
</html>
