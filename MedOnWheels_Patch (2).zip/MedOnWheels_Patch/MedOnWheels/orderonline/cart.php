<?php
session_start();

// Initialize the cart in the session if not exists
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Add an item to the cart
function addToCart($id, $name, $price, $qty) {
    $item = array(
        'id' => $id,
        'name' => $name,
        'price' => $price,
        'qty' => $qty
    );

    // Check if the item already exists in the cart
    $index = array_search($id, array_column($_SESSION['cart'], 'id'));

    if ($index !== false) {
        // Update the quantity if the item is already in the cart
        $_SESSION['cart'][$index]['qty'] += $qty;
    } else {
        // Add the item to the cart if it's not there
        $_SESSION['cart'][$index] = $item;
    }
}

// Update the quantity of an item in the cart
function updateCartQty($id, $qty) {
    $index = array_search($id, array_column($_SESSION['cart'], 'id'));

    if ($index !== false) {
        $_SESSION['cart'][$index]['qty'] = $qty;
    }
}

// Calculate and return the total amount in the cart
function calculateTotal() {
    $total = 0;

    foreach ($_SESSION['cart'] as $item) {
        $total += $item['qty'] * $item['price'];
    }

    return $total;
}
?>
