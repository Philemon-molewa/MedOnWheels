<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - MedOnWheels</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #fff;
            color: #333;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        header {
            background-color: #fff
            color: white;
            text-align: center;
            padding: 1em;
        }

        section {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
    </style>
</head>
<body>

<!-- Header -->
<header>
    <header class="masthead">
    <div class="container h-100">
        <div class="row h-100 align-items-center justify-content-center text-center">
            <div class="col-lg-10 align-self-end mb-4 page-title">
                <h3 class="text-white">Contact Us</h3>
                <hr class="divider my-4" />
            </div>
        </div>
    </div>
</header>
</header>

<!-- Contact Section -->
<section>
    <div align="center">
        <h3>Contact Information</h3>
        <p>Call us: <a href="tel:+0769939595">0769939595</a>, <a href="tel:+0823854222">0823854222</a></p>
        <p>Connect with us on: <a href="https://www.facebook.com/" target="_blank">Facebook</a>, <a href="https://twitter.com/" target="_blank">Twitter</a>, <a href="https://www.whatsapp.com/" target="_blank">Whatsapp</a>, <a href="https://www.instagram.com/" target="_blank">Instagram</a>, <a href="https://www.youtube.com/" target="_blank">Youtube</a></p>
        <p>Visit us at: 5 Andries Potgieter Boulevard, Vanderbijlpark, Gauteng, 1911, South Africa</p>
    </div>

    <!-- Contact Form -->
    <h3>Send us a Message</h3>
    <form action="save_data.php" method="post">
        <label for="name">Your Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="email">Your Email:</label>
        <input type="email" id="email" name="email" required>

        <label for="message">Your Message:</label>
        <textarea id="message" name="message" rows="4" required></textarea>

       
		<form action="save_data.php" method="post">
    
    
    
</form>
    </form>
	<a href="contacted.php"><button type="submit">Submit</button></a>
</section>



</body>
</html>
