<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - MedOnWheels</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f8f8;
            color: #333;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        header {
            background-color: #fff /* Blue color */
            color: white;
            text-align: center;
            padding: 1em;
        }

        section {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
    </style>
</head>
<body>

<!-- Masthead-->
        <header class="masthead">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center text-center">
				<img src="1600654681_photo-1504674900247-0877df9cc836.jpg" width="50%" height="50%" >
					<a href="index.php" style = "color: orange; text-align:center" class="btn btn-warning"><h2><b>Home</b> </h2></a>
					
                    
                    	 <h1 class="text-uppercase text-white font-weight-bold">Contact Us</h1>
                        <hr class="divider my-4" />
                    </div>
                    
                </div>
            </div>
        </header>

<!-- Contact Section -->
<section>
    <div align="center">
        <h3>Contacting...</h3>
        <p>Thank you for contacting us our response will be with you</p>
        <p>Connect with us on: <a href="https://www.facebook.com/" target="_blank">Facebook</a>, <a href="https://twitter.com/" target="_blank">Twitter</a>, <a href="https://www.whatsapp.com/" target="_blank">Whatsapp</a>, <a href="https://www.instagram.com/" target="_blank">Instagram</a>, <a href="https://www.youtube.com/" target="_blank">Youtube</a></p>
        <p>Visit us at: 5 Andries Potgieter Boulevard, Vanderbijlpark, Gauteng, 1911, South Africa</p>
    </div>
</section>

</body>
</html>