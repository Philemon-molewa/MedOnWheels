<!DOCTYPE html>
<html lang="en">
<header class="masthead">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-10 align-self-end mb-4 page-title">
                    	<h3 class="text-white">Welcome to <?php echo $_SESSION['setting_name']; ?></h3>
                        <hr class="divider my-4" />
                      

                    </div>
                    
                </div>
            </div>
        </header>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MedOnWheels</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f8f8;
        }

        header {
            background-color: #fff;
            color: white;
            text-align: center;
            padding: 1em;
        }

        section {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            text-align: center;
        }

        h1 {
            color: #fff;
        }

        p {
            color: green;
        }

        

       

        
    </style>
</head>

<body>

    <!-- Main Content Section -->
    <section>
        <h2>Your Health, Our Priority</h2>
        <h5>Experience the convenience of having your medicines delivered to your doorstep.</h5>
        <p>Get the medications you need without leaving your home! MedOnWheels offers a reliable and efficient delivery service that 
		brings your prescriptions straight to your door. Don't waste time waiting in line at the pharmacy when you can trust 
		MedOnWheels to deliver your medications quickly and conveniently.</p>
        <h5>Get started today!</h5><br>
			<img src="delivery.jpg" width= "450" height="350">
	<br>
	 <p>MedOnWheels is an online medicine ordering and delivery platform launched by group 66 in 2023. Couriers deliver medicine using cars, scooter, bikes or on foot. It is operational in over 200 cities across the country of south africa as of 2023</p>
       
    </section>

    

</body>

</html>
