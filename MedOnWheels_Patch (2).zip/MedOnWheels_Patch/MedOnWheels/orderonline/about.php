<!-- Masthead-->
        <header class="masthead">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-10 align-self-end mb-4" style="background: #0000002e;">
                    	 <h1 class="text-uppercase text-white font-weight-bold">About Us</h1>
                        <hr class="divider my-4" />
                    </div>
                    
                </div>
            </div>
        </header>

    <section class="page-section">
        <div class="container">
    <?php echo html_entity_decode($_SESSION['setting_about_content']) ?>        
            
        </div>
        </section>
		
		<!-- About-->
        <section class="page-section bg-primary" id="about">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8 text-center">
                        <h2 class="text-white mt-0">We've got what you need!</h2>
                        <hr class="divider light my-4" />
                        <p class="text-white-50 mb-4">MedOnWheels confidently delivers your medications right to your doorstep, ensuring you receive the prescriptions you need in a timely and convenient manner. </p>
                        <p class="text-white-50 mb-4">MedOnWheels was founded in 2021 by a group of 5 students who recognized the immense challenges faced by people in accessing their medication during the 2020 lockdown.
                           As a team, we discussed the difficulties we experienced during the lockdown, and one of our founders shared her grandmother's struggles in obtaining her medication on time. This sparked a bold idea - why not start a small business to deliver medication to the elderly?
                      We confidently seized the opportunity to start a small business and that is how MedOnWheels was born </p>
                        <p class="text-white-50 mb-4">MedOnWheels was born out of a desire to help people access their medication in a more convenient and efficient way. Initially, we physically went to the pharmacy to buy medication for our customers.
                           As we grew, we developed a website/online store to reach a wider audience and provide an even better service.
                           Thanks to this expansion, we are now able to serve a greater number of people, and we continuously strive to improve our services to make the process of obtaining medication as seamless as possible for our customers. </p>
                        <a class="btn btn-light btn-xl js-scroll-trigger" href="#services">Get Started!</a>
                    </div>
                </div>
            </div>
        </section>
        <!-- Services-->
        <section class="page-section" id="services">
            <div class="container">
                <h2 class="text-center mt-0">Our Team</h2>
                <hr class="divider my-4" />
                <div class="row">
                    <div class="col-lg-3 col-md-6 text-center">
                        <div class="mt-5">
                            <i class="fas fa-4x fa-gem text-primary mb-4"></i>
                            <h3 class="h4 mb-2">Lerato</h3>
                            <p class="text-muted mb-0">Co-Founder & </p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 text-center">
                        <div class="mt-5">
                            <i class="fas fa-4x fa-laptop-code text-primary mb-4"></i>
                            <h3 class="h4 mb-2">Tlotlo</h3>
                            <p class="text-muted mb-0">Co-Founder & </p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 text-center">
                        <div class="mt-5">
                            <i class="fas fa-4x fa-globe text-primary mb-4"></i>
                            <h3 class="h4 mb-2">Fhulu</h3>
                            <p class="text-muted mb-0">Co-Founder & </p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 text-center">
                        <div class="mt-5">
                            <i class="fas fa-4x fa-heart text-primary mb-4"></i>
                            <h3 class="h4 mb-2">Phil</h3>
                            <p class="text-muted mb-0">Co-Founder & </p>
                        </div>
                    </div>
                </div>
            </div>
<div class="col-lg-3 col-md-6 text-center">
                        <div class="mt-5">
                            <i class="fas fa-4x fa-heart text-primary mb-4"></i>
                            <h3 class="h4 mb-2">Joel</h3>
                            <p class="text-muted mb-0">Co-Founder & </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>