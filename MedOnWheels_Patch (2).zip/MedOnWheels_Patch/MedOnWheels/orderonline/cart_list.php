 <header class="masthead">
        <div class="container h-100">
            <div class="row h-100 align-items-center justify-content-center text-center">
                <div class="col-lg-10 align-self-end mb-4 page-title">
				<h1 style = "color: orange" ><b>Cart List</b></h1>
			
				<img src="1600654681_photo-1504674900247-0877df9cc836.jpg" width="50%" height="50%" >
                	<a href="index.php" class="btn btn-warning"> Home</a>
                    <hr class="divider my-4" />

                </div>
                
            </div>
        </div>
    </header>
<?php
session_start();

$connect = mysqli_connect("localhost", "root", "", "fos_db");

if (isset($_POST['add_to_cart'])) {
    if (isset($_SESSION['cart'])) {
        $session_array_id = array_column($_SESSION['cart'], "id");

        if (!in_array($_GET['id'], $session_array_id)) {
            $quantity = isset($_POST['quantity']) ? $_POST['quantity'] : 1;
            $session_array = array(
                'id' => $_GET['id'],
                'name' => isset($_POST['name']) ? $_POST['name'] : '',
                'price' => isset($_POST['price']) ? $_POST['price'] : '',
                'quantity' => $quantity
            );
            $_SESSION['cart'][] = $session_array;
        }
    } else {
        $quantity = isset($_POST['quantity']) ? $_POST['quantity'] : 1;
        $session_array = array(
            'id' => $_GET['id'],
            'name' => isset($_POST['name']) ? $_POST['name'] : '',
            'price' => isset($_POST['price']) ? $_POST['price'] : '',
            'quantity' => $quantity
        );
        $_SESSION['cart'][] = $session_array;
    }
}

?>

<!DOCTYPE html>
<html>

<head>
    <title>Shopping Cart</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script
</head>

<body>

    <div class="container-fluid">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">
                    
                    <div class="col-md-12">
                        <div class="row">

                            <?php

                            $query = "SELECT * FROM product_list";
                            $result = mysqli_query($connect, $query);

                            while ($row = mysqli_fetch_array($result)) { ?>
                                <div class="col-md-4">
                                    <form method="post" action="cart_list.php?id=<?= $row['id'] ?>">
                                        <img src="assets/img/<?php echo $row['img_path'] ?>" style='height: 150px;'>
                                        <h5><?= $row['name']; ?></h5>
                                        <h5>R<?= number_format($row['price'], 2); ?></h5>
                                        <input type="hidden" name="name" value="<?= $row['name'] ?>">
                                        <input type="hidden" name="price" value="<?= $row['price'] ?>">
                                        <input type="number" name="quantity" value="1" class="form-control">
                                        <input type="submit" name="add_to_cart" class="btn btn-warning btn-block my-2" value="Add To Cart">

                                    </form>
                                </div>

                            <?php
                            }

                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <h2 class="text-center">Item Selected</h2>
                    <?php

                    $output = "";
                    $total = 0; // Initialize $total before the loop

                    $output .= "
                        <table class='table table-bordered table-striped'>
                          <tr>
                           <th>ID</th>
                           <th>Item Name</th>
                           <th>Item Price</th>
                           <th>Item Quantity</th>
                           <th>Total Price</th>
                           <th>Action</th>
                           </tr>
                    ";

                    if (!empty($_SESSION['cart'])) {

                        foreach ($_SESSION['cart'] as $key => $value) {

                            $output .= "
                            <tr>
                                <td>" . $value['id'] . "</td>
                                <td>" . $value['name'] . "</td>
                                <td>" . $value['price'] . "</td>
                                <td>" . $value['quantity'] . "</td>
                                <td>R" . number_format($value['price'] * $value['quantity'], 2) . "</td>
                                <td>
                                    <a href='cart_list.php?action=remove&id=" . $value['id'] . "'>
                                        <button class='btn btn-danger btn-block'>Remove</button>
                                    </a>
                                </td>
                            </tr>
                        ";

                            $total = $total + $value['quantity'] * $value['price'];
                        }

                        $output .= "
                          <tr>
                          <td colspan='3'></td>
                          <td><b>Total Price</b></td>
                          <td>" . number_format($total, 2) . "</td>    
                          <td>
                            <a href='cart_list.php?action=clearall'>
                            <button class='btn btn-warning'>Clear</button>
                            </a>
                          </td>
                          </tr>

                        ";
                    }

                    $output .= "</table>";
                    echo $output;

                    ?>
                </div>
            </div>
        </div>
    </div>

    <?php

    if (isset($_GET['action'])) {

        if ($_GET['action'] == "remove") {
            // Handle remove logic
            // Remove the item with the specified id from the cart
            $remove_id = $_GET['id'];
            foreach ($_SESSION['cart'] as $key => $value) {
                if ($value['id'] == $remove_id) {
                    unset($_SESSION['cart'][$key]);
                }
            }
        } elseif ($_GET['action'] == "clearall") {
            unset($_SESSION['cart']);
        }
    }

    ?>

</body>

</html>

